#!/bin/bash

if [ "$1" = "-help" ]; then
	echo "Uso: $0 ORIGEN DESTINO"
	echo "Ejemplo: $0 /var/log /backup_dir"
	exit 0
fi

ORIGEN=$1
DESTINO=$2

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
	echo "Error: faltan argumentos."
	echo "Use $0 -help"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el directorio destino no existe :("
	exit 1
fi

if [ ! -d "$ORIGEN" ]; then
	echo "Error: el directorio origen no existe"
	exit 1
fi

FECHA=$(date +%Y%m%d)

NOMBRE=$(basename "$ORIGEN")

tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"

echo "Backup realizado correctamente papu."
